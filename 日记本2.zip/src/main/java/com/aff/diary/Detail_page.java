package com.aff.diary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.StringReader;

public class Detail_page extends AppCompatActivity {
    private Button addData;
    private Button deleteButton;
    private MyDatabaseHelper dbHelper;
    private EditText titleEdit;
    private EditText mainTextEdit;
    private EditText authorEdit;
    private Button addPhoto;
    private Bitmap bitmap;
    private ImageView imageView;
    public static final String IMAGE_UNSPECIFIED = "image/*";

//    private int idInt = intent.getIntExtra("id",-1);
//    private String id = String.valueOf(idInt);
    private String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        System.out.println("++++++++++++++++++++"+id);
//        id = "1";
        setContentView(R.layout.activity_detail_page);
        dbHelper = new MyDatabaseHelper(this,"Diary.db",null,1);
        dbHelper.getWritableDatabase();

        deleteButton = (Button)findViewById(R.id.delete_button);
        addData = (Button)findViewById(R.id.sendButton_detail);
        titleEdit = (EditText)findViewById(R.id.title_detail);
        mainTextEdit = (EditText)findViewById(R.id.mainText_detail);
        authorEdit = (EditText)findViewById(R.id.author_detail);
        imageView = (ImageView)findViewById(R.id.diary_image_add);
//        addPhoto = (Button)findViewById(R.id.addPhotoButton_detail);

        //与数据建立连接
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        //获取数据
        Cursor cursor = db.query("diary",new String[]{"title,author,mainText,image"}, "id=?", new String[]{id},null,null,null);

        //接收数据
        cursor.moveToFirst();
        titleEdit.setText(cursor.getString(cursor.getColumnIndex("title")));
        mainTextEdit.setText(cursor.getString(cursor.getColumnIndex("mainText")));
        authorEdit.setText(cursor.getString(cursor.getColumnIndex("author")));
//        System.out.println("++++++++++++++++++++" + cursor.getString(cursor.getColumnIndex("title")));
//        System.out.println("++++++++++++++++++++" + cursor.getString(cursor.getColumnIndex("mainText")));


        try{
            //接收数据库的blob数组

            byte[] imageBytes = cursor.getBlob(cursor.getColumnIndex("image"));

            System.out.println("++++++++++++++++++++" + imageBytes.length);

            //将blob转回bitmap
            bitmap = BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);

            //展示图片
            imageView.setImageBitmap(bitmap);
        }catch (Exception e){
//            imageView.setImageResource(R.drawable.test_image);
        }

        //提交修改
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //实例化EditText
                String author = authorEdit.getText().toString();
                String title = titleEdit.getText().toString();
                String mainText = mainTextEdit.getText().toString();

                SharedPreferences sp = getSharedPreferences("SP", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("author",author);
                editor.commit();

//                //开始组装数据
//                values.put("title",title);
//                values.put("author",author);
//                values.put("mainText",mainText);
//
                //图片转换为byte数组
//                ByteArrayOutputStream os = new ByteArrayOutputStream();
//                bitmap.compress(Bitmap.CompressFormat.PNG,100,os);
//                byte[] img = os.toByteArray();
//                //图片存储
//                values.put("image",img);
//
//                //上传数据
//                db.insert("Diary",null,values);
//                values.clear();

                db.execSQL("update diary set title = ?,mainText = ?,author = ? where id = ?",new Object[]{title,mainText,author,id});

                //删除此界面
                Detail_page.this.finish();
                Intent intent = new Intent(Detail_page.this,DiaryList.class);
                startActivity(intent);
            }
        });
//        addPhoto.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Intent.ACTION_PICK);
//                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,IMAGE_UNSPECIFIED);
//                startActivityForResult(intent, 1);
//            }
//        });

        //删除日记
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.execSQL("delete from diary where id = ?",new Object[]{id});
                //删除此界面
                Detail_page.this.finish();
                Intent intent = new Intent(Detail_page.this,DiaryList.class);
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(data != null){
                Uri uri = data.getData();
                try{
                    bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
                    imageView.setImageBitmap(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}



//<Button
//            android:layout_height="60dp"
//                android:layout_width="match_parent"
//                android:layout_marginTop="20dp"
//                android:layout_marginLeft="20dp"
//                android:layout_marginRight="20dp"
//                android:id="@+id/addPhotoButton_detail"
//                android:background="@drawable/button_add_photo"
//                android:layout_gravity="center"
//                android:textColor="@color/white"
//                android:text="+修改封面"
//                android:textSize="25dp"/>