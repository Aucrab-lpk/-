package com.aff.diary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class DiaryList extends AppCompatActivity {
    private List<Diary> diaryList = new ArrayList<Diary>();
    private MyDatabaseHelper dbHelper;
    private DiaryAdapter diaryAdapter;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_list);

//        测试List
//        initDiary();

        //准备连接数据库和adapter
        diaryAdapter = new DiaryAdapter(DiaryList.this,R.layout.diary_item,diaryList);
        ListView diaryList = (ListView)findViewById(R.id.diary_list);
        diaryList.setAdapter(diaryAdapter);
        dbHelper = new MyDatabaseHelper(this,"Diary.db",null,1);
        dbHelper.getWritableDatabase();
        Query();
        diaryList.setOnItemClickListener(new MyOnItemClickListener());



        //写日记按钮
        button = (Button) findViewById(R.id.addButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DiaryList.this,AddDiary.class);
                startActivity(intent);
                DiaryList.this.finish();
            }
        });
    }

    //查询数据
    public void Query(){
        Cursor cursor = dbHelper.getWritableDatabase().query("Diary",null,null,null,null,null,null,null);
        while (cursor.moveToNext()){
            String _id = cursor.getString(0);
            String title = cursor.getString(1);
            String author = cursor.getString(2);
            String time = cursor.getString(3);
            String mainText = cursor.getString(4);
            byte[] blob = cursor.getBlob(5);
            Diary diary = new Diary(Integer.parseInt(_id),title,author,time,mainText,blob);
            diaryList.add(diary);
        }
        Collections.reverse(diaryList);
    }
    private class MyOnItemClickListener implements AdapterView.OnItemClickListener{

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//            Cursor c = (Cursor)parent.getItemAtPosition(position);
            Intent intent = new Intent(DiaryList.this,Detail_page.class);
//            System.out.println("+++++++++++++++++"+(diaryList.size() - position));
//            String _id = String.valueOf(diaryList.size() - position);

//            System.out.println(_id);
            Diary diary = (Diary) diaryAdapter.getItem(position);
//            intent.putExtra("id", _id);
            String _id = String.valueOf(diary.getId());
            intent.putExtra("id",_id);
            startActivity(intent);

        }

    }
}
