package com.aff.diary;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class DiaryAdapter extends ArrayAdapter<Diary> {
    private int resourceId;

    private Bitmap bitmap;
    private byte[] imageBytes;

    public DiaryAdapter(Context context, int textViewResourceId, List<Diary> objects){
        super(context,textViewResourceId,objects);
        this.resourceId = textViewResourceId;

    }
    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Diary diary = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,null);
        ImageView diaryImage = (ImageView)view.findViewById(R.id.diary_image);
        diaryImage.setScaleType(ImageView.ScaleType.FIT_XY);
        TextView diaryTitle = (TextView)view.findViewById(R.id.diary_title);
        TextView diaryAuthor = (TextView)view.findViewById(R.id.diary_author);
        TextView diaryDate = (TextView)view.findViewById(R.id.diary_date);

        try{
            //接收数据库的blob数组
            imageBytes = diary.getImage();
            //将blob转回bitmap
            bitmap = BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);
            //展示图片
            diaryImage.setImageBitmap(bitmap);
        }catch(Exception e){
            diaryImage.setImageResource(R.drawable.empty_image);
        }



        diaryTitle.setText(diary.getTitle());
        diaryAuthor.setText(diary.getAuthor());
        diaryDate.setText(diary.getDate());
        notifyDataSetChanged();
        return view;
    }


}
