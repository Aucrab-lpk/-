package com.aff.diary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class AddDiary extends AppCompatActivity {

    private Button addData;
    private MyDatabaseHelper dbHelper;
    private EditText titleEdit;
    private EditText mainTextEdit;
    private EditText authorEdit;
    private Button addPhoto;
    private Bitmap bitmap;
    private ImageView imageView;
    private boolean addedPhoto = false;
    private byte[] img;
    public static final String IMAGE_UNSPECIFIED = "image/*";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_diary);



        dbHelper = new MyDatabaseHelper(this,"Diary.db",null,1);
        dbHelper.getWritableDatabase();
//        scrollView = (ScrollView)findViewById(R.id.scrollView);
        addData = (Button)findViewById(R.id.sendButton);
        titleEdit = (EditText)findViewById(R.id.title);
        mainTextEdit = (EditText)findViewById(R.id.mainText);
        authorEdit = (EditText)findViewById(R.id.author);
        imageView = (ImageView)findViewById(R.id.diary_image_add);
        addPhoto = (Button)findViewById(R.id.addPhotoButton);
        SharedPreferences sp = getSharedPreferences("SP",Context.MODE_PRIVATE);
        String spAuthor = sp.getString("author",null);
        if(spAuthor != null){
            authorEdit.setText(spAuthor);
        }


        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //与数据建立连接
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();

                //实例化EditText
                String author = authorEdit.getText().toString();
                String title = titleEdit.getText().toString();
                String mainText = mainTextEdit.getText().toString();
                if(title.equals("")|| mainText.equals("")){
                    Toast.makeText(AddDiary.this,"标题或内容不得为空",Toast.LENGTH_SHORT).show();
                }else{
                    SharedPreferences sp = getSharedPreferences("SP", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("author",author);
                    editor.commit();

                    //开始组装数据
                    values.put("title",title);
                    values.put("author",author);
                    values.put("mainText",mainText);

                    if(addedPhoto){
                        try {
                            //图片转换为byte数组
                            ByteArrayOutputStream os = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG,100,os);
                            img = os.toByteArray();

                            //图片存储
                            values.put("image",img);
                        }catch (Exception e){

                        }
                    }

                    //上传数据
                    db.insert("Diary",null,values);
                    values.clear();
                }


                //删除此界面
                addedPhoto = false;
                AddDiary.this.finish();
                Intent intent = new Intent(AddDiary.this,DiaryList.class);
                startActivity(intent);
            }
        });
        addPhoto.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                addedPhoto = true;
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,IMAGE_UNSPECIFIED);

                startActivityForResult(intent,1);
                addedPhoto = true;
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(data != null){
                Uri uri = data.getData();
                try{
                    bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
                    imageView.setImageBitmap(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}