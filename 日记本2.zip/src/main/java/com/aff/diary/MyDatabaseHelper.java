package com.aff.diary;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    public static final String CREATE_BOOK = "create table diary(id integer primary key autoincrement,title text,author text,date timestamp default CURRENT_TIMESTAMP,mainText text,image Blob)";
//    public static final String FIRST_DIARY = "insert into diary (title,author,mainText) values (欢迎使用Today-Diary日记本,Today-Diary,Today-Diary是一款日记本应用)";
    private Context mContext;
    public MyDatabaseHelper(Context context,String name,SQLiteDatabase.CursorFactory factory,int version){
        super(context,name,factory,version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_BOOK);
        Toast.makeText(mContext,"数据库创建成功",Toast.LENGTH_SHORT).show();
//        db.execSQL(FIRST_DIARY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
